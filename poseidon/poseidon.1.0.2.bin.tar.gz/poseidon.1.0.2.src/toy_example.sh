#!/bin/bash
OLD_PWD=$PWD
mkdir inc exc
wget ftp://ftp.ncbi.nih.gov/pub/taxonomy/taxdump.tar.gz
mkdir inc/Genomes inc/Index
mkdir exc/Genomes exc/Index
cp taxdump.tar.gz inc/Index
cp taxdump.tar.gz exc/Index
cd exc/Genomes
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/H_sapiens/Assembled_chromosomes/seq/hs_ref_GRCh38.p2_chrMT.fa.gz
gunzip hs_ref_GRCh38.p2_chrMT.fa.gz
cd  ../Index
tar xvf taxdump.tar.gz
cd ../../inc/Genomes
wget ftp://ftp.ncbi.nlm.nih.gov/genomes/Viruses/all.fna.tar.gz
tar xvf all.fna.tar.gz
rm -rf A* B* C* D* E* F* G* I* J* K* L* M* N* O* P* Q* R* S* T* U* V* W* X* Y* Z* Ha* HC* He* Hi* HM* Ho* Humulus* Hy* H_* insect* unidentified* Human_papillomavirus* Human_herpesvirus* Human_T* Human_a* Human_b* Human_e* Human_g* Human_i* Human_k* Human_m* Human_p* Human_r*
cd ../Index
tar xvf taxdump.tar.gz
cd $OLD_PWD
./poseidon -f file_list -r inc -e exc
